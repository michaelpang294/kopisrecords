import { Link } from "react-router-dom";
import { informationCategories } from "./scripts/picksOfTheWeek";
import { typography as type } from "./styles/typography";

const linkClass = `${type.small} inline-flex min-h-11 items-center py-2 text-[#c0b4a3] transition-colors hover:text-[#efe8dc] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#cbb79c] focus-visible:outline-offset-4 motion-reduce:transition-none`;

const headingClass = `${type.itemTitle} mt-0 mb-4 text-[#efe8dc]`;

const socials = [
  { name: "Instagram", href: "https://www.instagram.com/kopisrecords/" },
  { name: "Telegram", href: "https://t.me/kopisrecords" },
  { name: "Carousell", href: "https://carousell.app.link/x9L3b0YYW2b" },
];

export default function Footer() {
  const information = informationCategories.filter(
    (item) => item.name.trim().toLowerCase() !== "admin",
  );

  return (
    <footer
      aria-labelledby="footer-title"
      className={`${type.body} border-t border-white/10 bg-[#1b1612] px-[18px] pb-6 pt-12 text-[#efe8dc] sm:px-6 lg:px-10 lg:pt-16`}
    >
      {/* Column headings are H3s within this labelled H2 section. */}
      <h2 id="footer-title" className="sr-only">
        Explore Kopi’s Records
      </h2>

      <div className="mx-auto max-w-[1320px]">
        <div className="grid grid-cols-2 gap-x-6 gap-y-10 lg:grid-cols-[1.5fr_1fr_1fr_1fr] lg:gap-12">
          <div className="col-span-2 lg:col-span-1">
            <Link
              to="/"
              aria-label="Kopi’s Records home"
              className={`${type.brand} inline-block text-[#efe8dc] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#cbb79c] focus-visible:outline-offset-4`}
            >
              Kopi’s Records
            </Link>

            <p className={`${type.small} mb-0 mt-4 max-w-[290px] text-[#c0b4a3]`}>
              We hope that you find something you like in our crates. Thank you for your support!
            </p>

            <a
              href="mailto:kopisrecords@gmail.com"
              className={`${linkClass} mt-3 break-all`}
            >
              kopisrecords@gmail.com
            </a>
          </div>

          <nav aria-labelledby="footer-shop-title">
            <h3 id="footer-shop-title" className={headingClass}>
              Explore the crates
            </h3>
            <ul className="m-0 list-none p-0">
              <li>
                <Link to="/shop" className={linkClass}>
                  Shop all records
                </Link>
              </li>
              <li>
                <Link to="/shop?sort=newest" className={linkClass}>
                  New arrivals
                </Link>
              </li>
              <li>
                <Link to="/request" className={linkClass}>
                  Request a record
                </Link>
              </li>
            </ul>
          </nav>

          <nav aria-labelledby="footer-information-title">
            <h3 id="footer-information-title" className={headingClass}>
              Here to help
            </h3>
            <ul className="m-0 list-none p-0">
              {information.map((item) => (
                <li key={item.name}>
                  <Link to={`/${item.link.replace(/^\/+/, "")}`} className={linkClass}>
                    {item.name}
                  </Link>
                </li>
              ))}
              <li>
                <a href="mailto:kopisrecords@gmail.com" className={linkClass}>
                  Contact us
                </a>
              </li>
            </ul>
          </nav>

          <nav
            aria-labelledby="footer-social-title"
            className="col-span-2 border-t border-white/10 pt-7 lg:col-span-1 lg:border-0 lg:pt-0"
          >
            <h3 id="footer-social-title" className={headingClass}>
              Stay in rotation
            </h3>
            <p className={`${type.small} mb-3 mt-0 max-w-[270px] text-[#c0b4a3]`}>
              New arrivals weekly, preorders for new releases, and updates here and there.
            </p>
            <ul className="m-0 flex list-none flex-wrap gap-x-6 p-0 lg:block">
              {socials.map((social) => (
                <li key={social.name}>
                  <a
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`${social.name} (opens in a new tab)`}
                    className={`${linkClass} gap-2`}
                  >
                    {social.name}
                    <span aria-hidden="true" className="text-[#cbb79c]">
                      ↗
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <div
          className={`${type.meta} mt-10 flex flex-col gap-2 border-t border-white/10 pt-6 text-[#c0b4a3] sm:flex-row sm:items-center sm:justify-between lg:mt-14`}
        >
          <p className="m-0">© {new Date().getFullYear()} Kopi’s Records</p>
          <p className="m-0">Built and run with love.</p>
        </div>
      </div>
    </footer>
  );
}
